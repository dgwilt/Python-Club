## Extend the Quiz Project

### Ways to Build On It
 - Use a **menu loop** to let players pick a topic (maths, animals, colours) before starting.
 - Add a loop that **shuffles questions** each game until a target score is reached.
 - Keep a looped **name entry** with validation so you can print a personalised scoreboard.
