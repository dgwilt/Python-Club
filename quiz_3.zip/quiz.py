
QUESTIONS = [
  ["What is 2 + 2? ", "4"],
  ["What colour do you get by mixing red and blue? ", "purple"],
  ["Which animal barks? ", "dog"],
]

def ask_answer(pQuestion):
  # Basic validation: must be non-empty
  while not(ans == ""):
    ans = input(pQuestion).strip().lower()
    if ans == "":
      print("Please type an answer.")
  return ans

print("Quiz Time!")
score = 0
i = 0
while i < len(QUESTIONS):
  q, correct = QUESTIONS[i]
  answer = ask_answer(q)
  if answer == correct:
    print("✅ Correct!")
    score = score + 1
  else:
    print(f"❌ Not quite. The answer was '{correct}'.")
  i = i + 1

print(f"Your score: {score}/{len(QUESTIONS)}")
