
QUESTIONS = [
  ["What is 2 + 2? ", "4"],
  ["What colour do you get by mixing red and blue? ", "purple"],
  ["Which animal barks? ", "dog"],
]

print("Quiz Time!")
score = 0

q, correct = QUESTIONS[0]
answer = ""
while answer == "":
  answer = input(q).strip().lower()
  if answer == "":
    print("Please type an answer.")
if answer == correct:
  print("✅ Correct!")
  score = score + 1
else:
  print(f"❌ Not quite. The answer was '{correct}'.")

q, correct = QUESTIONS[1]
answer = ""
while answer == "":
  answer = input(q).strip().lower()
  if answer == "":
    print("Please type an answer.")
if answer == correct:
  print("✅ Correct!")
  score = score + 1
else:
  print(f"❌ Not quite. The answer was '{correct}'.")

q, correct = QUESTIONS[2]
answer = ""
while answer == "":
  answer = input(q).strip().lower()
  if answer == "":
    print("Please type an answer.")
if answer == correct:
  print("✅ Correct!")
  score = score + 1
else:
  print(f"❌ Not quite. The answer was '{correct}'.")

print(f"Your score: {score}/{len(QUESTIONS)}")
