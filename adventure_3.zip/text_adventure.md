## Extend the Text Adventure Project

### Ways to Build On It
 - Add a **turn counter loop** that ends the game after a certain number of moves.
 - Create a **room loop** that allows examining items multiple times until the player finds a clue.
 - Add a **play again** loop that restarts the adventure from the entrance.
