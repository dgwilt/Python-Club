print("Welcome to the Cave of Whispers!")
print("Find the treasure and avoid getting lost.")
location = "entrance"
moves = 0
finished = False

# Turn loop
while not finished:
  if location == "entrance":
    choice = ""
    while choice not in ["left", "right", "quit"]:
      choice = input("You see tunnels to the LEFT and RIGHT. Which way? ").strip().lower()
      if choice not in ["left", "right", "quit"]:
        print("That's not a valid option!")
    if choice == "left":
      location = "puzzle"
    elif choice == "right":
      location = "deadend"
    else:
      print("You leave the cave.")
      finished = True
  elif location == "puzzle":
    choice = ""
    while choice not in ["please", "quit"]:
      choice = input("A door asks: 'Say the magic word' (hint: 'please'). What do you say? ").strip().lower()
      if choice not in ["please", "quit"]:
        print("That's not a valid option!")
    if choice == "please":
      location = "treasure"
    else:
      print("You step back from the door.")
      location = "entrance"
  elif location == "deadend":
    choice = ""
    while choice not in ["back", "quit"]:
      choice = input("Dead end! Go BACK to the entrance? ").strip().lower()
      if choice not in ["back", "quit"]:
        print("That's not a valid option!")
    if choice == "back":
      location = "entrance"
    else:
      print("You leave the cave.")
      finished = True
  elif location == "treasure":
    print("You found the treasure! 🎉")
    finished = True

  moves += 1
  if moves >= 12:
    print("You took too long... The cave rumbles and you run out!")
    finished = True


print("Game over.")
