def get_choice(pQuestion, pOptions):
  ans = ""
  while ans not in pOptions:
    ans = input(pQuestion).strip().lower()
    if ans not in pOptions:
      print("That's not a valid option!")

  return ans

print("Welcome to the Cave of Whispers!")
print("Find the treasure and avoid getting lost.")
location = "entrance"
moves = 0
finished = False

# Turn loop
while not finished:
  if location == "entrance":
    choice = get_choice("You see tunnels to the LEFT and RIGHT. Which way? ", ["left", "right", "quit"])
    if choice == "left":
      location = "puzzle"
    elif choice == "right":
      location = "deadend"
    else:
      print("You leave the cave.")
      finished = True
  elif location == "puzzle":
    choice = get_choice("A door asks: 'Say the magic word' (hint: 'please'). What do you say? ", ["please", "quit"])
    if choice == "please":
      location = "treasure"
    else:
      print("You step back from the door.")
      location = "entrance"
  elif location == "deadend":
    choice = get_choice("Dead end! Go BACK to the entrance? ", ["back", "quit"])
    if choice == "back":
      location = "entrance"
    else:
      print("You leave the cave.")
      finished = True
  elif location == "treasure":
    print("You found the treasure! 🎉")
    finished = True

  moves += 1
  if moves >= 12:
    print("You took too long... The cave rumbles and you run out!")
    finished = True


print("Game over.")
