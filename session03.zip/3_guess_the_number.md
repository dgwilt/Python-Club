# Guess the Number
## Aim
 - The computer has chosen a number between 1 and 10.  
 - Keep asking the user to guess until they get it right.

## Instructions
 - Change the `_` in the code so that the program achieves the aim above
 - The first line with `_` has two pieces of syntax missing, and the comparison operator
 - The second line with `_` needs to convert the user's answer into a number
 - The third line with `_` needs to use the correct comparison operator

**Example output:**
```
Guess the number (1-10): 4
Too low! Try again.
Guess the number (1-10): 7
Well done, you guessed it!
```
