secret = 7
guess = 0

_ not(guess == secret) _
    guess = _(input("Guess the number (1-10): "))
    if guess < secret:
        print("Too low! Try again.")
    elif guess _ secret:
        print("Too high! Try again.")

print("Well done, you guessed it!")
