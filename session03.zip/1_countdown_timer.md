# Countdown Timer
## Aim
Write a program that counts down from 5 to 1, then prints **Go!**

## Instructions
 - Change the `_` in the code so that the program counts down from 5 to 1
 - The first line with `_` has two pieces of syntax missing
 - The second line with `_` needs to make the count get smaller by one

**Example output:**
```
5
4
3
2
1
Go!
```
