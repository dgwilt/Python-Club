# Repeat After Me
## Aim
 - Ask the user to type something, and repeat it back.  
 - Stop when they type **stop**.

## Instructions
 - Change the `_` in the code so that the program asks the user to type something, and repeats it back
 - The first line with `_` has two pieces of syntax missing, and the comparison operator
 - The second line with `_` needs to get the user to type an answer
 
 **Example output:**
```
Say something (or type 'stop' to finish): hello
You said: hello
Say something (or type 'stop' to finish): stop
Goodbye!
```
