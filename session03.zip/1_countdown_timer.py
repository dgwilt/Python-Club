count = 5
_ count > 0 _
    print(count)
    count = _

print("Go!")
