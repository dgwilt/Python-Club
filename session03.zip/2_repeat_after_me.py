text = ""

_ not(text _ "stop") _
    text = _("Say something (or type 'stop' to finish): ")
    print(f"You said: {text}")

print("Goodbye!")
