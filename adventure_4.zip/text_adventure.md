## Extend the Text Adventure Project
 - Start by displaying your own title and aim of the game
 - Pick 4 or 5 places for your game
 - Choose your start place and end place on lines 4 and 5
 - In each place change the `elif place == xxx` code for the name of your place
 - In each place use the `print()` statement to tell the player when they are seeing.
 - In each place give the player a choice to make on `choice = input("question")`
 - Update the place variable depending on the player's choice `place = xxx`

## Next time
 - We will add some `while` loops in case the user types something wrong by accident, they can try again

