import json
with open("book.json","r") as f:
    data = json.load(f)

with open("book.json","w") as f:
    json.dump(data,f,indent=2)
