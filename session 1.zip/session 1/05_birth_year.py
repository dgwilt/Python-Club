age = int(input("How old are you? "))
year = ___"What is the current year? "___
birth_year = year ___ age
