# Secret Formula

**Summary:** Ask for a number, add 3, double it, then minus 4.

## Learning objectives
- Understand order of operations with brackets
- Store results in variables
- Use f-strings for clear messages

## Instructions
1. Read a number as an integer.
2. Apply the algorithm: add 3, double it, then minus 4
3. print the result.

## Starter code
```python
n = int(input("Enter a number: "))
result = ___
print(___"The secret formula gives {___}")
```

## Sample I/O
| Input | Output |
|---|---|
| `5` | `The secret formula gives 12` |
| `10` | `The secret formula gives 22` |

## Extensions
- Let the user choose the constants (e.g., +a, ×b, −c).
- Show each step as a separate print line.
