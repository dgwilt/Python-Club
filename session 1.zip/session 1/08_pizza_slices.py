pizzas = ___"How many pizzas? "___
people = ___"How many people? "___
slices_each = (pizzas ___ 8) ___ people
print(f"Each person gets {___} slices")
