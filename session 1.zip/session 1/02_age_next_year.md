# Age Next Year

**Summary:** Ask for age and show what it will be next year.

## Learning objectives
- Convert input text to numbers using int()
- Perform simple arithmetic
- Use f-strings to display results

## Instructions
1. Ask for the user's age and convert it to an integer.
2. Add 1 and print the result in a sentence.
3. Look at Sample I/O for the expected result

## Starter code
```python
age = int(input("How old are you? "))
```

## Sample I/O
| Input | Output |
|---|---|
| `11` | `Next year you will be 12` |
| `13` | `Next year you will be 14` |

## Extensions
- Also show their age in 5 years' time.
- Show their age in months (approximate as age * 12).
