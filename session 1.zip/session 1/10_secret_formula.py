n = int(input("Enter a number: "))
result = ___
print(___"The secret formula gives {___}")
