# Challenge 3 - Temperature Check

# Ask the user for today's temperature
temp = int(input("What is the temperature today (°C)? "))

# Add if / elif / else to give advice

print("It's really hot! ☀️ Stay cool and drink water.")

print("It's a nice day! 🌤 Enjoy the weather.")

print("Brrr, it's chilly! ❄️ Wear a jumper.")