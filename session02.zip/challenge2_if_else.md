# ⚡️ Challenge 2 – High or Low?

**Goal:** Use an `if / else` statement to make two different outcomes.

### Instructions
1. Ask the user to type a number.
2. Use `>` (the **greater than** operator) to check if the number is more than 100.
3. If it does, print `"That number is high ⚡️"`.
4. Otherwise, print `"That number is low 🌙"`.

### Example
```
Enter a number: 7
That number is low 🌙
```
```
Enter a number: 112
That number is high ⚡️
```
