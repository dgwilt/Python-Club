# 🐍 Challenge 1 – The Secret Word

**Goal:** Use an `if` statement to check a condition.

### Instructions
1. Run the code.  
2. Type in different words when asked.  
3. Add an `if` statement that checks **if** the word is `"python"`.  
4. If it is, print:  
   ```
   Correct! 🐍 You know the secret word!
   ```

### Hints
- Use `==` to check if two things are the same.
- Python is case-sensitive! `"Python"` is **not** the same as `"python"`.
