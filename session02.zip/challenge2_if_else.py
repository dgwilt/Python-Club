# Challenge 2 - High or Low?

# Ask the user for a number
number = int(input("Enter a number: "))

# Check if the number is above 100 or not
# Complete the if/else below!

print("That number is high ⚡️")

print("That number is low 🌙")