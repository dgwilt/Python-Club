# 🌡 Challenge 3 – Temperature Check

**Goal:** Use `if / elif / else` to handle **three different** possibilities.

### Instructions
1. Ask the user for today’s temperature in °C.  
2. Use conditions:
   - If it's **over 30**, print `"It's really hot! ☀️ Stay cool and drink water."`
   - Else if it's **over 15**, print `"It's a nice day! 🌤 Enjoy the weather."`
   - Otherwise, print `"Brrr, it's chilly! ❄️ Wear a jumper."`

### Hint
Each `elif` lets you test another condition without starting a new `if`.

### Example
```
What is the temperature today (°C)? 10
Brrr, it's chilly! ❄️ Wear a jumper.
```
