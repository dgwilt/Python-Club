# Challenge 1 - The Secret Word

# Ask the user for a secret word
word = input("What is the secret word? ")

# If the word is "python", print a message
# Write your if statement below!


print("Correct! 🐍 You know the secret word!")