emoji = input("Enter your favourite emoji: ")
print(f"{emoji ___ }")
