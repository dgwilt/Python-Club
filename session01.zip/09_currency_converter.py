hong_kong_dollars = float(___("Amount in HKD (HK$): "))
rate = 0.93
yuan = hong_kong_dollars ___ rate
print(f"¥{yuan:___} (using rate {___})")
