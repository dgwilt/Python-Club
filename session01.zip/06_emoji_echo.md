# Emoji Echo

**Summary:** Ask for a favourite emoji and print it 5 times using *.

## Learning objectives
- Work with strings and repetition
- Understand the * operator for strings
- Use f-strings with expressions

## Instructions
1. Ask for a favourite emoji.
2. Use the * operator to repeat the emoji 5 times.

## Starter code
```python
emoji = input("Enter your favourite emoji: ")
print(f"{emoji ___ }")
```

## Sample I/O
| Input | Output |
|---|---|
| `😀` | `😀😀😀😀😀` |
| `🐍` | `🐍🐍🐍🐍🐍` |

## Extensions
- Ask how many times to repeat and use that number.
- Repeat a short word instead of an emoji.
