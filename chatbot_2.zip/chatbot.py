# A tiny chatbot

print("Hello, I am Chatty, your friendly computer.")
user_name = input("What is your name? ").strip()
print(f"Hi {user_name}!")

mood = input("How are you feeling today (happy, tired, bored, excited)? ").strip().lower()
if mood == "happy":
    print("That is brilliant. Keep smiling!")
elif mood == "tired":
    print("Remember to rest and drink some water.")
elif mood == "bored":
    print("Try a five-minute walk or a quick drawing challenge.")
elif mood == "excited":
    print("Amazing. What has got you excited today?")
else:
    print("Thanks for sharing. I hope your day goes well.")

favourite_food = input("What is your favourite food? ").strip().lower()
if favourite_food in ("pizza", "pasta", "chocolate"):
    print(f"Nice choice. {favourite_food.capitalize()} is popular here too.")
elif favourite_food in ("broccoli", "carrots"):
    print("Healthy and strong. Good for you!")
else:
    print(f"{favourite_food.capitalize()} sounds tasty.")

# Simple keyword-based reply
user_message = input("Say something and I will try to respond: ").strip().lower()
if "hello" in user_message or "hi" in user_message:
    print("Hello there! I am glad you are here.")
elif "joke" in user_message:
    print("Here is a joke: Why did the computer get cold? It forgot to close its Windows!")
elif "bye" in user_message or "goodbye" in user_message:
    print("Goodbye. Talk again soon.")
else:
    print("Interesting. I am thinking about that now.")

print(f"It was nice chatting with you, {user_name}.")
