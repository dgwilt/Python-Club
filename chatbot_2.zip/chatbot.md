## Extend the Chat Bot Project

This chatbot lives in `chatbot.py`. Run it with `python chatbot.py` to test changes often.

### Ways to Build On It
- Add extra mood checks by copying the existing `if` blocks and comparing the input with simple words.
- Ask another question (for example about hobbies), store it in a new variable, and use it in a reply.
- Introduce a `chat_points` variable that increases each time the user gives a positive answer and show it at the end.
- Let the user rate the chat at the end and print a special goodbye message when the rating is high.
