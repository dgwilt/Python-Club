## Extend the Text Adventure Project
 - Create some sub-programs with the `def` keyword to break your game up into smaller pieces (This is called `decomposition` in computer science)
 - Add a `while` loop to protect your game from incorrect user inputs

## Last session next time
 - Focus on adding content to your games and sharing with each other.
