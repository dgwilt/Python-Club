# ----------------------
# Sub Programs
# ----------------------

def from_the_entrance():
  print("You are at the entrance to the cave. It is dark and scary.")
  choice = input("Do you go LEFT or RIGHT? ").strip().lower()

  # --- New code here vvvvvvv ----
  while choice not in ['left','right']:
    print("I didn't understand that ...")
    choice = input("Do you go LEFT or RIGHT? ").strip().lower()
  # --- New code here ^^^^^^^ ----

  if choice == "left":
    place = "puzzle"   # Entrance -> Puzzle
  elif choice == "right":
    place = "deadend"  # Entrance -> Dead End
  return place

def from_the_puzzle():
  print("You are faced with a puzzle and a small cave elf offering to help you.")
  choice = input("Do you ask nicely with PLEASE or DEMAND the answer? ").strip().lower()

  # --- New code here vvvvvvv ----
  while choice not in ['please','demand']:
    print("I didn't understand that ...")
    choice = input("Do you ask nicely with PLEASE or DEMAND the answer? ").strip().lower()
  # --- New code here ^^^^^^^ ----

  if choice == "please":
    place = "treasure" # Puzzle -> Treasure
  elif choice == "demand":
    print("The elf doesn't let you in.")
    place = "entrance"
  return place

# ----------------------
# Main Program
# ----------------------

print("Welcome to the Cave of Whispers!")
print("Find the treasure and avoid getting lost.")

place = "entrance"
end = "exit"
moves = 0

# Turn loop
while not (moves == 10 or place == end):
  moves = moves + 1
  print(f"You are at the {place}")
  # ---- ENTRANCE -------
  if place == "entrance":
    place = from_the_entrance()
  # ---- PUZZLE -------
  elif place == "puzzle":
    place = from_the_puzzle()
  # ---- DEAD END -------
  elif place == "deadend":
    print("There is a rock face in front of you. Looks like you've gone the wrong way.")
    choice = input("Do you go BACK or GIVE UP? ").strip().lower()
    if choice == "back":
      place = "entrance" # Dead End -> Entrance
    else:
      print("You leave the cave.")
      place = "exit"
  # ---- TREASURE -------
  elif place == "treasure":
    print("You found the treasure! 🎉")
    print("You retrace your steps to the cave exit")
    place = "exit"

print("You have exited the cave.")
print("Game over.")
