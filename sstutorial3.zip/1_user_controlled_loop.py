######################
# Global Variables
######################
choice = 0
num = 0.0

######################
# Sub Programs
######################

def showMenu():
    print("Enter your choice:")
    print(" 1) Square")
    print(" 2) Cube")
    print(" 3) Quit")

######################
# Main Program
######################


# ===> Write a program that keeps asking the user to enter a choice 
#      until they choose to quit.  After the choice has been entered, 
#      if it is a square or a cube then ask the user to enter a number
#      and then print it either squared (raised to the power of 2) or 
#      cubed (raised to the power of 3)

showMenu()
choice = int(input("Enter a choice"))




# ===> The lines you need are below, but are not indented correctly 
#      and are not in the correct order
elif choice == 2:
num = float(input("Enter a number: "))
choice = int(input("Enter a choice"))
print(num ** 2)
while choice != 3:
if choice == 1:
showMenu()
print(num ** 3)
