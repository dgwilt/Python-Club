# -------------
# Constants
# -------------
OUT_FILE = "Power_Square.txt"
COMMA = ","
LF = "\n"

# -------------
# Global Variables
# -------------
outLine = ""
size = 0
row = 0
column = 0

# -------------
# Main Program
# -------------

# ===> Open the output file for writing

# ===> Get the user to enter the size of the square

# ===> Loop over the rows of the square


    # ===> Loop over the columns of the square

        # ===> Calculate the value and build the outLine


    # ===> Write the line to the file


# ===> Close the file



# DONT CHANGE THIS BIT ...
# Let's just check that the file was written correctly!
# As you can't see it in PythonSponge
f = open(OUT_FILE,"r")
for line in f:
    print(line.strip())
f.close()
