data = input("Enter some data for validation: ")

# Data entered is a number
print("{} is a number".format(data))

# Data entered is a number in the range 3 to 7 inclusive
print("{} is a number in the range 3 to 7 inclusive".format(data))

# Data entered is a number but not in the range 3 to 7 inclusive
print("{} is a number but not in the range 3 to 7 inclusive".format(data))

# Data entered is not a number
print("{} is not a number".format(data))

# Data entered is all letters
print("{} is all letters".format(data))

# Data entered is not all letters
print("{} is not all letters".format(data))

# Data entered does not have punctuation or spaces, just numbers and/or letters
print("{} does not have punctuation or spaces, just numbers and/or letters".format(data))

# Data entered is a mix of letters and numbers
print("{} is a mix of letters and numbers".format(data))

# Data entered ends with a letter
print("{} ends with a letter".format(data))

# Data entered ends with a number
print("{} ends with a number".format(data))

total = 0

print("The sum of all numbers in {} is {}".format(data,total))

