## Extend the Quiz Project

Open `quiz.py` to change the questions or add new features. Run it with `python quiz.py` after each tweak to check your work.

### Ways to Build On It
- Add more questions by copying the existing pattern and updating the `score` when answers are correct.
- Keep a `wrong_answers` variable and display how many times the player slipped up.
- Create a bonus question that only appears if the player answers the main quiz perfectly.
- Introduce a `total_questions` variable so the final message always shows the right maximum score.
