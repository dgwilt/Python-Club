# A short quiz

print("Welcome to the Mini Quiz! Topic: General Knowledge")
name = input("Enter your name: ").strip()
score = 0

# Q1
answer1 = input("Q1) What colour do you get when you mix blue and yellow? ").strip().lower()
if answer1 == "green":
    print("Correct!")
    score = score + 1
else:
    print("Not quite. The answer is green.")

# Q2
answer2 = input("Q2) How many minutes are there in one hour? ").strip()
if answer2 == "60":
    print("Correct!")
    score = score + 1
else:
    print("Close, but it is 60.")

# Q3
answer3 = input("Q3) What is the capital city of France? ").strip().lower()
if answer3 == "paris":
    print("Correct!")
    score = score + 1
else:
    print("Good try. It is Paris.")

print(f"\n{name}, your final score is {score} out of 3.")
if score == 3:
    print("Perfect score! Excellent work.")
elif score == 2:
    print("Great job. Almost there!")
elif score == 1:
    print("Nice effort. Keep practising.")
else:
    print("Do not worry. Have another go later.")
