age = int(input("How old are you? "))
