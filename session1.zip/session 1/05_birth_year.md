# Birth Year Finder

**Summary:** Ask for age and current year to estimate birth year.

## Learning objectives
- Use multiple numeric inputs
- Perform subtraction
- Store intermediate results in variables

## Instructions
1. Ask for age and current year as integers.
2. Subtract age from year to estimate birth year.
3. Print the estimate of the year you were born

## Starter code
```python
age = int(input("How old are you? "))
year = ___"What is the current year? "___
birth_year = year ___ age
```

## Sample I/O
| Input | Output |
|---|---|
| `age=12, year=2025` | `I estimate you were born in 2013` |
| `age=11, year=2025` | `I estimate you were born in 2014` |

## Extensions
- Also show their age in the year 2030.
- Ask for the month number and include it in a sentence.
