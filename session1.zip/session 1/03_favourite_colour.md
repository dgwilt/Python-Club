# Favourite Colour

**Summary:** Ask for a favourite colour and echo it in a sentence.

## Learning objectives
- Work with string inputs
- Use variables and f-strings

## Instructions
1. Ask for favourite colour using input().
2. Print a sentence using that colour variable.
3. Look at the Sample I/O and be careful with punctuation.

## Starter code
```python
colour = ___("What is your favourite colour? ")
```

## Sample I/O
| Input | Output |
|---|---|
| `Green` | `Nice! Green is a great choice.` |
| `Purple` | `Nice! Purple is a great choice.` |

## Extensions
- Ask for a second favourite colour and show both in one sentence.
- Ask for favourite emoji and include it.
