# Currency Converter

**Summary:** Ask for Hong Kong dollars and show the amount in Chinese yuan using a fixed rate (× 0.93).

## Learning objectives
- Work with float inputs
- Use a constant exchange rate variable
- Format numbers with 2 decimal places

## Instructions
1. Ask for an amount in Hong Kong dollars (HKD).
2. Multiply by a fixed rate to convert to Chinese yuan (CNY)
3. Print the result, formatted to 2 dp. using `:.2f` after the variable

## Starter code
```python
hong_kong_dollars = float(___("Amount in HKD (HK$): "))
rate = 0.93
yuan = hong_kong_dollars ___ rate
print(f"¥{yuan:___} (using rate {___})")
```

## Sample I/O
| Input | Output |
|---|---|
| `100` | `¥93.00 (using rate 0.93)` |
| `12.5` | `¥11.63 (using rate 0.93)` |

## Extensions
- Allow the user to input the rate instead of using a fixed one.
- Also show the amount back in Hong Kong dollars to check.
