# Pizza Slices

**Summary:** Ask for pizzas and people, show slices per person (8 slices per pizza).

## Learning objectives
- Combine multiple numeric inputs
- Use multiplication and division
- Introduce floats vs integers informally

## Instructions
1. Fill in the `___` to get the inputs as numbers 
2. Assume 8 slices per pizza.
3. Calculate slices per person and print the result.

## Starter code
```python
pizzas = ___"How many pizzas? "___
people = ___"How many people? "___
slices_each = (pizzas ___ 8) ___ people
print(f"Each person gets {___} slices")
```

## Sample I/O
| Input | Output |
|---|---|
| `pizzas=2, people=5` | `Each person gets 3.2 slices` |
| `pizzas=3, people=6` | `Each person gets 4.0 slices` |

## Extensions
- Format to 2 decimal places using round(slices_each, 2).
- Ask for slices-per-pizza as another input.
