colour = ___("What is your favourite colour? ")
