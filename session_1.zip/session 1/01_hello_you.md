# Hello You!

**Summary:** Ask for the user's name and greet them using an f-string.

## Learning objectives
- Use input() to collect text
- Use variables to store information
- Use f-strings to format output

## Instructions
1. Create a variable called name using input().
2. Print a greeting using an f-string.

## Starter code
```python
name = input("What is your name? ")
```

## Sample I/O
| Input | Output |
|---|---|
| `Asha` | `Hello Asha!` |
| `Zaki` | `Hello Zaki!` |

## Extensions
- Add a second input for a favourite hobby and include it in the greeting.
- Ask for the day of the week and include it in the message.
