# Name Combiner

**Summary:** Ask for first and last names and combine them.

## Learning objectives
- Collect multiple string inputs
- Concatenate strings with a space
- Use variables and f-strings

## Instructions
1. Ask for first and last names.
2. Combine them with a space in between using an f-string.

## Starter code
```python
first = input("First name: ")
last = ___"Last name: "___
full_name = f"{___} {___}"
print(f"Nice to meet you, {___}!")

```

## Sample I/O
| Input | Output |
|---|---|
| `First=Kai, Last=Tan` | `Nice to meet you, Kai Tan!` |
| `First=Asha, Last=Lee` | `Nice to meet you, Asha Lee!` |

## Extensions
- Ask for a nickname and include it in brackets.
- Print the name in reverse order: last, first.
