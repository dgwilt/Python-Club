first = input("First name: ")
last = ___"Last name: "___
full_name = f"{___} {___}"
print(f"Nice to meet you, {___}!")
