# Magic Number ×7

**Summary:** Ask for a number and multiply it by 7.

## Learning objectives
- Convert input to an integer
- Use multiplication
- Use f-strings to format results

## Instructions
1. Ask the user to pick a number.
2. Convert the input to a number using int()
3. Multiply by 7 and print the result.
4. Look at Sample I/O for the expected output

## Starter code
```python
number = ___(input("Pick a number: "))
```

## Sample I/O
| Input | Output |
|---|---|
| `3` | `Your magic result is 21` |
| `10` | `Your magic result is 70` |

## Extensions
- Try different multipliers by asking for another input.
- Display both the original number and the result.
