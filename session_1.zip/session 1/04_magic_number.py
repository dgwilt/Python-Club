number = ___(input("Pick a number: "))
