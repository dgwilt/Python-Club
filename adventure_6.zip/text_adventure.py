# ----------------------
# Sub Programs
# ----------------------

def from_the_entrance():
  print("You are at the entrance to the cave. It is dark and scary.")
  choice = input("Do you go LEFT or RIGHT? ").strip().lower()

  # --- Validation code here vvvvvvv ----
  while choice not in ['left','right']:
    print("I didn't understand that ...")
    choice = input("Do you go LEFT or RIGHT? ").strip().lower()
  # --- Validation code here ^^^^^^^ ----

  if choice == "left":
    place = "puzzle"   # Entrance -> Puzzle
  elif choice == "right":
    place = "deadend"  # Entrance -> Dead End
  return place

def from_the_puzzle():
  print("You are faced with a puzzle and a small cave elf offering to help you.")
  choice = input("Do you ask nicely with PLEASE or DEMAND the answer? ").strip().lower()

  # --- Validation code here vvvvvvv ----
  while choice not in ['please','demand']:
    print("I didn't understand that ...")
    choice = input("Do you ask nicely with PLEASE or DEMAND the answer? ").strip().lower()
  # --- Validation code here ^^^^^^^ ----

  if choice == "please":
    place = "treasure" # Puzzle -> Treasure
  elif choice == "demand":
    print("The elf doesn't let you in, but as he leaves you see a strength potion by his seat")
    place = "entrance"

    # --- vvvvvvv Put something in your bag --------
    bag.append("strength potion")
    # --- ^^^^^^^ Put something in your bag --------

  return place

# ----------------------
# Main Program
# ----------------------

print("Welcome to the Cave of Whispers!")
print("Find the treasure and avoid getting lost.")

# -- vvvvv Start with an empty bag
bag = []
# -- ^^^^^ Start with an empty bag
place = "entrance"
end = "exit"
moves = 0

# Turn loop
while not (moves == 10 or place == end):
  moves = moves + 1
  print(f"You are at the {place}")
  # ---- ENTRANCE -------
  if place == "entrance":
    place = from_the_entrance()
  # ---- PUZZLE -------
  elif place == "puzzle":
    place = from_the_puzzle()
  # ---- DEAD END -------
  elif place == "deadend":
    print("There is a rock face in front of you. Looks like you've gone the wrong way.")
    choice = input("Do you go BACK or GIVE UP? ").strip().lower()
    if choice == "back":
      place = "entrance" # Dead End -> Entrance
    else:
      print("You leave the cave.")
      place = "exit"
  # ---- TREASURE -------
  elif place == "treasure":
    print("You found the treasure! 🎉")

    # --- vvvvvvv Check your bag --------
    if "strength potion" in bag:
      bag.remove("strength potion")
      print("Using the strength potion, you carry the treasure and retrace your steps to the cave exit")
      place = "exit"
    # --- ^^^^^^^ Check your bag --------
    else:
      print("However, you're not strong enough to carry it.")
      print("You return to the cave entrance.")
      place = "entrance"

print("You have exited the cave.")
print("Game over.")
