## Extend the Text Adventure Project
 - Use `bag.append("item")` to put an item in your bag
 - Use `if "item" in bag:` to run some code if you've picked up the thing you need
 - Use `bag.remove("item")` to take something out of your bag

## Last session
 - Focus on adding content and improving game play
