## Extend the Chat Bot Project

### Ways to Build On It
 - This chatbot uses **one** `while` loop to check for a specific answer.
 - It asks the user to type **hello** and repeats the question until the user types exactly `hello`.
 - After that, the chatbot continues normally.
