print("I am ChatBot!")
greet = input("Say hello to start: ").strip().lower()

while not greet == "hello":
  print("Try typing 'hello'")
  greet = input("Say hello to start: ")

print("Nice to meet you!")
name = input("What is your name? ")
print(f"Great to meet you, {name}!")

topic = ""
while topic not in ("music", "sports", "food"):
  topic = input("What would you like to talk about (music, sports, food)? ").strip().lower()
  if topic not in ("music", "sports", "food"):
    print("I'm not sure about that!")

if topic == "music":
  print("I like catchy songs. What do you like to listen to?")
elif topic == "sports":
  print("I enjoy watching matches. Do you play a sport?")
elif topic == "food":
  print("Fruit and pasta are tasty. What is your favourite food?")
