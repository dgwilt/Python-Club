# A tiny text adventure

print("Welcome to the Woodland Path!")
player_name = input("What is your name, traveller? ")
print(f"Nice to meet you, {player_name}.")

print("You arrive at a fork in the path.")
choice1 = input("Do you go LEFT towards the river, or RIGHT into the trees? ").strip().lower()

if choice1 == "left":
    print(f"{player_name}, you follow the path and reach a calm river.")
    action = input("Do you SWIM across or BUILD a raft? ").strip().lower()
    if action == "swim":
        print("The water is freezing, but you make it across. You find a small pouch of coins on the bank!")
    elif action == "build":
        print("Your raft works! You drift across safely and spot a rare flower you can sell later.")
    else:
        print("Unsure what to do, you sit by the river and enjoy the view. Peaceful, but not very adventurous!")

elif choice1 == "right":
    print(f"{player_name}, you step under the trees. It is quiet and a little spooky.")
    action = input("A fox appears. Do you FOLLOW it or IGNORE it? ").strip().lower()
    if action == "follow":
        print("You follow the fox to a hidden clearing with ancient carvings. A secret of the forest!")
    elif action == "ignore":
        print("You keep walking and find a fallen log perfect for a rest. You feel refreshed.")
    else:
        print("You hesitate and the fox runs away. Maybe next time!")

else:
    print("You stay at the fork, unable to choose. Sometimes not choosing is still a choice!")

print("The adventure ends here. Thanks for playing!")
