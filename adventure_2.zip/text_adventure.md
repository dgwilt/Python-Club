## Extend the Text Adventure Project

Edit `text_adventure.py` to create new story paths. Run `python text_adventure.py` regularly to see how your changes feel while playing.

### Ways to Build On It
- Add another decision after each branch by reusing the same `if` structure to create a longer story.
- Keep a `treasure_found` variable that flips to `"yes"` when the player succeeds and print a special ending if it is `"yes"`.
- Create a `bravery` score that goes up or down depending on choices and show it at the end.
- Ask the player if they want to play again and restart the story when they type `"yes"`.
